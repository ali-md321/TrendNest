const BaseUser = require('./BaseUserModel');
const mongoose = require('mongoose');

module.exports = BaseUser.discriminator('Seller', new mongoose.Schema({
  shopName: { type: String, required: true },
  gstNumber: { type: String, required: true },
  businessAddress: { type: String, required: true },
  bankDetails: {
    accountHolderName: String,
    accountNumber: String,
    ifscCode: String,
    bankName: String,
  },
  socialHandles: {
    website: String,
    instagram: String,
    facebook: String,
    twitter: String,
    linkedin: String,
  },
  ratings: { type: Number, default: 0 },
  totalReviews: { type: Number, default: 0 },
  productActivity: [{
    date: { type: Date, default: Date.now },
    count: { type: Number, default: 1 }
  }],
  reviewActivity: [{
    date: { type: Date, default: Date.now },
    count: { type: Number, default: 1 }
  }],
  addedProducts: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
}));
