const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Product title is required'],
    trim: true
  },
  description: {
    type: String,
  },
  highlights: [String],
  brand: String,
  category: {
    type: String,
    required: true,
    enum: [
      "Mobiles&Tablets", "Fashion", "Electronics", "Home&Furniture",
      "TVs&Appliances", "Beauty,Food&More", "Grocery","Others"
    ]
  },
  price: {
    type: Number,
    required: [true, 'Price is required']
  },
  discountedPrice: Number,
  discountPercent: Number,
  stock: {
    type: Number,
    default: 1
  },
  images: [{ type: String }],
  seller:  {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  ratings: {
    type: Number,
    default: 0
  },
  numOfReviews: {
    type: Number,
    default: 0
  },
  reviews: [
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: "ReviewRating"
    }
  ],
  isTrending: {
    type: Boolean,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Product", productSchema);
