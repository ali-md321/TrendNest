const mongoose = require('mongoose');

const addressSchema = new mongoose.Schema({
  name: { type: String, required: true },
  phone: { type: String, required: true },
  pincode: { type: String, required: true },
  locality: { type: String },
  address: { type: String},
  city: { type: String },
  state: { type: String, required: true },
  landmark: { type: String },
  alternatePhone: { type: String },
  addressType: { type: String, enum: ['Home', 'Work'], default: 'Home' },
}, { _id: false });

const orderItemSchema = new mongoose.Schema({
  product:  { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  quantity: { type: Number, required: true },
  totalPrice:    { type: Number, required: true },
});

const orderSchema = new mongoose.Schema({
  user : { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  productDetails : orderItemSchema,
  address : addressSchema,
  paymentMethod : { type: String, enum: ['COD', 'UPI', 'CARD', 'ONLINE', 'WALLET', 'WALLET+ONLINE'], default: 'COD' },
  paymentStatus : { type: String, enum: ['Pending', 'Paid', 'Failed'], default: 'Pending' },
  paymentInfo: {
    walletDeducted: { type: Number, default: 0 },
    paymentIntentId: { type: String },
    method: { type: String },
    razorpay_payment_id: { type: String },
    razorpay_order_id: { type: String },
    razorpay_signature: { type: String }
  },
  orderStatus : {
    type: String,
    enum: ['Placed', 'Confirmed', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled', 'Return Request', 'Returned'],
    default: 'Placed'
  },
  review : {type: mongoose.Schema.Types.ObjectId, ref: 'ReviewRating'},
  orderedAt:    { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);

