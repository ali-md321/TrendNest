const BaseUser = require('./BaseUserModel');
const mongoose = require('mongoose');

module.exports = BaseUser.discriminator('Deliverer', new mongoose.Schema({
  vehicleType: {
    type: String,
    enum: ['Bike', 'Scooter', 'Car', 'Van', 'Other'],
    required: true
  },
  licenseNumber: { type: String, required: true },

  serviceAreas: [{
    city: String,
    pincode: String
  }],

  availability: { type: Boolean },

  workingHours: {
    startTime: { type: String, default: '' }, // e.g., "09:00"
    endTime: { type: String, default: '' },     // e.g., "18:00"
    workingDays: [{
    type: String,
    enum: [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday'
    ]
    }]
  },

  assignedOrders: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Order' }],
  returnPickups: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Order' }],

  // COD Summary
  codSummary: {
    pendingAmount: { type: Number, default: 0 }, // COD yet to be submitted
    collectedToday: { type: Number, default: 0 }, // For today's settlements
    history: [{
      date: { type: Date, default: Date.now },
      amount: Number,
      status: { type: String, enum: ['Pending', 'Submitted'], default: 'Pending' }
    }]
  },

  // Performance metrics for dashboard
  performance: {
    totalDeliveries: { type: Number, default: 0 },
    onTimeDeliveries: { type: Number, default: 0 },
    failedDeliveries: { type: Number, default: 0 },
    averageDeliveryTime: { type: Number, default: 0 }, // in minutes
    rating: { type: Number, default: 0 },
    completionRate: { type: Number, default: 0 }, // %
    weeklyStats: [{
      weekStart: { type: Date }, // e.g. Monday of the week
      deliveries: { type: Number, default: 0 },
      pickups: { type: Number, default: 0 }
    }]
  },

  // Notifications
  notifications: [{
    message: String,
    type: { type: String, enum: ['Order', 'Payment', 'System', 'Alert'] },
    read: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now }
  }],

  completedDeliveries: { type: Number, default: 0 },
  deliveryRating: { type: Number, default: 0 },

  joinedAt: { type: Date, default: Date.now }
}));
