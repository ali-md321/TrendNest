const BaseUser = require('./BaseUserModel');
const mongoose = require('mongoose');

module.exports = BaseUser.discriminator('Customer', new mongoose.Schema({
  wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
  cart: [{
    _id: false,
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    quantity: { type: Number, default: 1 },
  }],
  walletBalance: { type: Number, default: 0 },
  savedForLater: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
  orders: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Order' }],
  reviewRatings: [{ type: mongoose.Schema.Types.ObjectId, ref: 'ReviewRating' }],
}));
