const Seller = require("../models/SellerModel");
const Order = require("../models/orderModel");
const Product = require("../models/productModel");
const { uploadImageToBucket, deleteImageFromBucket } = require("../config/googleCloudConfig");
const catchAsync = require("../middlewares/catchAsync");
const ReviewRating = require("../models/reviewRatingModel");
const ErrorHandler = require("../utils/ErrorHandler");
const { assignDeliveries, updateWeeklyActivity } = require("../utils/relatedFunc");

exports.addProductController = catchAsync(async (req, res) => {
  const {title,description,highlights,brand,category,price,discountedPrice,stock} = req.body;
  const userId = req.userId;
  if (!req.files || req.files.length === 0) {
    throw new ErrorHandler('At least one image is required', 400);
  }
  const uploadedImageUrls = [];
  for (const file of req.files) {
    const url = await uploadImageToBucket(file.buffer, `products/${Date.now()}_${file.originalname}`, file.mimetype);
    uploadedImageUrls.push(url);
  }
  const product = await Product.create({
    title,
    description,
    highlights: highlights ? JSON.parse(highlights) : [],
    brand,
    category,
    price,
    discountedPrice,
    discountPercent: price && discountedPrice ? Math.round(((price - discountedPrice) / price) * 100) : 0,
    stock,
    images: uploadedImageUrls,
    seller: req.userId
  });
  let user = await Seller.findById(userId);
  user.addedProducts.push(product);
  await user.save({ validateBeforeSave: false });
  await updateWeeklyActivity(userId,"Seller", 'productActivity');
  res.status(201).json({
    success: true,
    message: 'Product added successfully',
    sellerProduct : product,
  });
});

exports.showSellerProductsController = catchAsync(async(req,res) => {
  const seller = await Seller.findById(req.userId).populate("addedProducts");
  const products = seller.addedProducts;
  res.json({
    message : "Seller Products Fetched!..",
    sellerProducts : products
  })
})

exports.getSellerProductController = catchAsync(async (req, res) => {
  const {productId} = req.params;
  const product = await Product.findById(productId).lean();

  if (!product) {
    return res.status(404).json({ success: false, message: 'Product not found' });
  }

  const reviews = await ReviewRating.find({ product: productId })
    .populate('user', 'name email')
    .sort({ createdAt: -1 });

  product.reviews = reviews;
  res.json({
    success: true,
    message: 'Seller Product Fetched!',
    sellerProduct: product
  });
});

exports.editSellerProductController = catchAsync(async (req, res) => {
  const { productId } = req.params;
  const {title,description,highlights,brand,category,price,discountedPrice,stock,images} = req.body;
  const userId = req.userId;
  
  const product = await Product.findById(productId);
  if (!product) {
    throw new ErrorHandler('Product not found', 404);
  }
  if (product.seller.toString() !== userId) {
    throw new ErrorHandler('Unauthorized to edit this product', 403);
  }
  if (!images && (!req.files || req.files.length === 0)) {
    throw new ErrorHandler('At least one image is required', 400);
  }

  const uploadedImageUrls = [];
  for (const oldUrl of product.images) {
    if(images && images.includes(oldUrl)){
      uploadedImageUrls.push(oldUrl);
    }else{
      await deleteImageFromBucket(oldUrl);
    }
  }
  for (const file of req.files) {
    const url = await uploadImageToBucket(
      file.buffer,
      `products/${Date.now()}_${file.originalname}`,
      file.mimetype
    );
    uploadedImageUrls.push(url);
  }

  product.title = title;
  product.description = description;
  product.highlights = highlights ? JSON.parse(highlights) : [];
  product.brand = brand;
  product.category = category;
  product.price = price;
  product.discountedPrice = discountedPrice;
  product.discountPercent = price && discountedPrice
    ? Math.round(((price - discountedPrice) / price) * 100)
    : 0;
  product.stock = stock;
  product.images = uploadedImageUrls;

  await product.save();

  res.status(200).json({
    success: true,
    message: 'Product updated successfully',
    sellerProduct : product,
  });
});

exports.deleteSellerProductController = catchAsync(async (req, res) => {
  const { productId } = req.params;
  const userId = req.userId;

  const product = await Product.findById(productId);
  if (!product) {
    throw new ErrorHandler('Product not found', 404);
  }
  if (product.seller.toString() !== userId) {
    throw new ErrorHandler('Unauthorized to delete this product', 403);
  }

  for (const url of product.images) {
    await deleteImageFromBucket(url);
  }

  await Product.findByIdAndDelete(productId);
  // await Seller.findByIdAndUpdate(userId, {
  //   $pull: { addedProducts: productId },
  // });

  res.status(200).json({
    success: true,
    message: 'Product deleted successfully',
  });
});

exports.getNeedToShipController = catchAsync(async (req, res) => {
  const sellerId = req.userId; // current logged-in seller

  const sellerProducts = await Product.find({ seller: sellerId }).select("_id");
  const sellerProductIds = sellerProducts.map(p => p._id);

  const twoDaysAgo = new Date();
  twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);

  const orders = await Order.find({
    "productDetails.product": { $in: sellerProductIds },
    $or: [
      { orderStatus: {$in : ["Shipped","Placed","Confirmed"]} },
      { 
        orderStatus: "Delivered",
        deliveredAt: { $gte: twoDaysAgo }
      }
    ]
  })
    .populate({
      path: "productDetails.product",
      select: "title price images seller"
    })
    .populate("user", "name email")
    .populate("deliverer","name email");

  res.status(200).json({
    status: "success",
    count: orders.length,
    orders
  });
});

exports.updateShipmentController = catchAsync(async (req, res) => {
  const { orderId } = req.params;

  const order = await Order.findById(orderId).populate("productDetails.product","seller title price");
  if (!order) {
    throw new ErrorHandler("Order Not Found", 404);
  }

  const product = await Product.findById(order?.productDetails?.product);
  if (!product) {
    throw new ErrorHandler("Product Not Found", 404);
  }

  const quantityOrdered = order?.productDetails?.quantity || 1;
  if (product.stock < quantityOrdered) {
    throw new ErrorHandler("Insufficient Stock", 400);
  }
  product.stock -= quantityOrdered;
  await product.save({ validateBeforeSave: false });

  order.orderStatus = "Shipped";
  order.shippedAt = Date.now();
  await order.save({ validateBeforeSave: false });

  const assignedDeliverer = await assignDeliveries(order);
  res.status(200).json({
    success: true,
    message: "Order marked as shipped and stock updated successfully",
    order,
  });
});

exports.getMetricesController = catchAsync(async(req,res) => {
  const seller = await Seller.findById(req.userId)
  res.json({success : true, seller});
})

exports.needToAcceptReturnController = catchAsync(async (req, res) => {
  const sellerId = req.userId;

  const seller = await Seller.findById(sellerId);
  if (!seller) throw new ErrorHandler("Seller not found", 404);

  const orders = await Order.find({
    orderStatus: "ReturnRequest",
    $or: [
      { "productDetails.product": { $in: seller.addedProducts } },
      { "productDetails.deletedProductSnapshot.seller": sellerId }
    ]
  })
    .populate("user", "name email")
    .populate("productDetails.product", "title images price");

  res.json({ msg: "Returns needing acceptance", orders });
});

exports.returnAcceptController = catchAsync(async (req, res) => {
    const { orderId } = req.params;
    const order = await Order.findById(orderId).populate("productDetails.product","seller title price");

    if (!order) throw new ErrorHandler("Order not found",404);
    if (order.productDetails.product.seller?.toString() !== req.userId) {
      throw new ErrorHandler("Not authorized to accept return of this order", 401);
    }
    if (order.orderStatus !== "ReturnRequest")
      throw new ErrorHandler("Invalid status for Return acceptance",400);

    order.orderStatus = "ReturnAccepted";
    order.returnAcceptedAt = new Date();
    await order.save({validateBeforeSave : false});

    res.json({ message: "Return accepted, waiting for deliverer pickup", order });

})

exports.needToRefundController = catchAsync(async (req, res) => {
  const sellerId = req.userId;

  const seller = await Seller.findById(sellerId);
  if (!seller) throw new ErrorHandler("Seller not found", 404);

  const orders = await Order.find({
    orderStatus: "ReturnPickedUp",
    $or: [
      { "productDetails.product": { $in: seller.addedProducts } },
      { "productDetails.deletedProductSnapshot.seller": sellerId }
    ]
  })
    .populate("user", "name email")
    .populate("productDetails.product", "title images price");

  res.json({ msg: "Returns needing refund", orders });
});

exports.refundOrderController = catchAsync(async (req, res) => {
    const { orderId } = req.params;
    const order = await Order.findById(orderId).populate("productDetails.product","seller title price");

    if (!order)  throw new ErrorHandler("Order not found",404);
    if (order.productDetails.product.seller?.toString() !== req.userId) {
      throw new ErrorHandler("Not authorized to refund this order", 401);
    }
    if (order.orderStatus !== "ReturnPickedUp")
       throw new ErrorHandler("Invalid status for refund",400);

    order.orderStatus = "Refunded";
    order.refundedAt = new Date();
    await order.save({validateBeforeSave : false});

    res.json({ msg: "Order refunded successfully", order });
})

exports.rejectOrderController = catchAsync(async(req,res) => {
  const { orderId } = req.params;
    const order = await Order.findById(orderId).populate("productDetails.product","seller title price");

    if (!order)  throw new ErrorHandler("Order not found",404);
    if (order.productDetails.product.seller?.toString() !== req.userId) {
      throw new ErrorHandler("Not authorized to reject this order", 401);
    }
    if (!["ReturnRequest","ReturnPickedUp","Placed","Confirmed"].includes(order.orderStatus))
       throw new ErrorHandler("Invalid status for rejection",400);

    order.orderStatus = "Rejected";
    order.rejectedAt = new Date();
    await order.save({validateBeforeSave : false});

    res.json({ msg: "Order rejected successfully", order });
})
